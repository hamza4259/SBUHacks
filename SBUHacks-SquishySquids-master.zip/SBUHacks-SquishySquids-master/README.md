# SBUHacks-SquishySquids


This is a submission to SBUHacks made by RealGoose, hamza4259, and Daniel Schwartz.

Start the application by running FinalWithPics.py, after which the application will load a new browser window with a route made between your location and the nearest hospital. A simple Python GUI will load that will also show 5 hospitals nearest to your location. 


